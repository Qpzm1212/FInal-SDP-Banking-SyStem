package kz.shop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Db {
    private static final String URL  = "jdbc:postgresql://localhost:5432/Azik3";
    private static final String USER = "postgres";
    private static final String PASS = "1001";

    private Db() {} // Singleton style: запрет new

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
