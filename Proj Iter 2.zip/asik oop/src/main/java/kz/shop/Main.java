package kz.shop;

import kz.shop.auth.Role;
import kz.shop.auth.Security;
import kz.shop.auth.Session;
import kz.shop.factory.RepoFactory;
import kz.shop.service.Validation;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static BigDecimal applyDiscount(BigDecimal total) {
        if (total.compareTo(new BigDecimal("20000")) >= 0) {
            return total.multiply(new BigDecimal("0.90"));
        }
        return total;
    }

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {

            while (true) {
                System.out.println("\n=== MENU ===");
                System.out.println("1) Login (by userId)");
                System.out.println("2) List products");
                System.out.println("3) Create order");
                System.out.println("4) Add to order");
                System.out.println("5) Pay order");
                System.out.println("6) Full order description (JOIN)");
                System.out.println("7) Admin/Manager: Add category");
                System.out.println("8) Admin/Manager: Add product");
                System.out.println("0) Exit");
                System.out.print("Choose: ");
                String cmd = sc.nextLine();

                if (cmd.equals("1")) {
                    login(sc);
                } else if (cmd.equals("2")) {
                    listProducts();
                } else if (cmd.equals("3")) {
                    mustLogin();
                    int oid = createOrder(Session.userId());
                    System.out.println("Created orderId=" + oid);
                } else if (cmd.equals("4")) {
                    mustLogin();
                    System.out.print("orderId: ");
                    int orderId = Integer.parseInt(sc.nextLine());
                    System.out.print("productId: ");
                    int pid = Integer.parseInt(sc.nextLine());
                    System.out.print("qty: ");
                    int qty = Integer.parseInt(sc.nextLine());
                    addToOrder(orderId, pid, qty);
                    System.out.println("Added. Total recalculated.");
                } else if (cmd.equals("5")) {
                    mustLogin();
                    System.out.print("orderId: ");
                    int orderId = Integer.parseInt(sc.nextLine());
                    payOrder(orderId, Session.userId());
                    System.out.println("PAID!");
                } else if (cmd.equals("6")) {
                    System.out.print("orderId: ");
                    int orderId = Integer.parseInt(sc.nextLine());
                    RepoFactory.orders().printFullOrderDescription(orderId);
                } else if (cmd.equals("7")) {
                    Security.require(Role.ADMIN, Role.MANAGER);
                    System.out.print("category name: ");
                    String name = sc.nextLine();
                    addCategory(name);
                    System.out.println("Category added.");
                } else if (cmd.equals("8")) {
                    Security.require(Role.ADMIN, Role.MANAGER);
                    System.out.print("product name: ");
                    String name = sc.nextLine();
                    System.out.print("price: ");
                    BigDecimal price = new BigDecimal(sc.nextLine());
                    System.out.print("stock: ");
                    int stock = Integer.parseInt(sc.nextLine());
                    System.out.print("categoryId: ");
                    int catId = Integer.parseInt(sc.nextLine());
                    addProduct(name, price, stock, catId);
                    System.out.println("Product added.");
                } else if (cmd.equals("0")) {
                    break;
                } else {
                    System.out.println("Unknown command.");
                }
            }

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    static void mustLogin() {
        if (!Session.isAuth()) throw new RuntimeException("Please login first.");
    }

    static void login(Scanner sc) throws SQLException {
        System.out.print("Enter userId: ");
        int userId = Integer.parseInt(sc.nextLine());

        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement("SELECT role FROM users WHERE id=?")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new SQLException("User not found");
                String roleStr = rs.getString("role");
                Role role = Role.valueOf(roleStr);
                Session.login(userId, role);
                System.out.println("Logged in as userId=" + userId + " role=" + role);
            }
        }
    }

    static void listProducts() throws SQLException {
        String sql =
                "SELECT p.id, p.name, c.name AS category, p.price, p.stock " +
                "FROM products p " +
                "JOIN categories c ON c.id = p.category_id " +
                "ORDER BY p.id ";


        ArrayList<String> rows = new ArrayList<>();

        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("ID | Name | Category | Price | Stock");
            while (rs.next()) {
                String row = rs.getInt("id") + " | " +
                        rs.getString("name") + " | " +
                        rs.getString("category") + " | " +
                        rs.getBigDecimal("price") + " | " +
                        rs.getInt("stock");
                rows.add(row);
            }
        }

        // Lambda expression (req #3)
        rows.stream().forEach(System.out::println);
    }

    static int createOrder(int userId) throws SQLException {
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO orders(user_id, status, total) VALUES (?, 'CREATED', 0) RETURNING id")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    static void addToOrder(int orderId, int productId, int qty) throws SQLException {
        Validation.positiveInt(qty, "qty must be > 0");

        try (Connection con = Db.get()) {

            BigDecimal price;
            int stock;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT price, stock FROM products WHERE id=?")) {
                ps.setInt(1, productId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Product not found");
                    price = rs.getBigDecimal("price");
                    stock = rs.getInt("stock");
                }
            }
            if (stock < qty) throw new SQLException("Not enough stock. Available=" + stock);

            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO order_items(order_id, product_id, qty, unit_price) " +
                            "VALUES (?, ?, ?, ?) " +
                            "ON CONFLICT (order_id, product_id) DO UPDATE SET qty = order_items.qty + EXCLUDED.qty")) {
                ps.setInt(1, orderId);
                ps.setInt(2, productId);
                ps.setInt(3, qty);
                ps.setBigDecimal(4, price);
                ps.executeUpdate();
            }

            recalcTotal(con, orderId);
        }
    }

    static void recalcTotal(Connection con, int orderId) throws SQLException {
        BigDecimal total;
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COALESCE(SUM(qty * unit_price),0) AS total FROM order_items WHERE order_id=?")) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                total = rs.getBigDecimal("total");
            }
        }
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE orders SET total=? WHERE id=?")) {
            ps.setBigDecimal(1, total);
            ps.setInt(2, orderId);
            ps.executeUpdate();
        }
    }

    static void payOrder(int orderId, int userId) throws SQLException {
        try (Connection con = Db.get()) {
            con.setAutoCommit(false);
            try {
                BigDecimal total;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT total FROM orders WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, orderId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("Order not found");
                        total = rs.getBigDecimal("total");
                    }
                }

                BigDecimal discounted = applyDiscount(total);

                // FIX: убрал лишнюю "ф"
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE orders SET total=? WHERE id=?")) {
                    ps.setBigDecimal(1, discounted);
                    ps.setInt(2, orderId);
                    ps.executeUpdate();
                }

                BigDecimal balance;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT balance FROM users WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, userId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("User not found");
                        balance = rs.getBigDecimal("balance");
                    }
                }

                // FIX: если balance == discounted — это достаточно, поэтому < 0
                if (balance.compareTo(discounted) < 0) throw new SQLException("Not enough balance");

                try (PreparedStatement items = con.prepareStatement(
                        "SELECT product_id, qty FROM order_items WHERE order_id=?");
                     PreparedStatement lockProd = con.prepareStatement(
                             "SELECT stock FROM products WHERE id=? FOR UPDATE");
                     PreparedStatement decStock = con.prepareStatement(
                             "UPDATE products SET stock = stock - ? WHERE id=? AND stock >= ?")) {

                    items.setInt(1, orderId);
                    try (ResultSet rs = items.executeQuery()) {
                        while (rs.next()) {
                            int pid = rs.getInt("product_id");
                            int qty = rs.getInt("qty");

                            lockProd.setInt(1, pid);
                            try (ResultSet pr = lockProd.executeQuery()) {
                                if (!pr.next()) throw new SQLException("Product missing id=" + pid);
                                int stock = pr.getInt("stock");
                                if (stock < qty) throw new SQLException("Not enough stock for product id=" + pid);
                            }

                            decStock.setInt(1, qty);
                            decStock.setInt(2, pid);
                            decStock.setInt(3, qty);
                            int updated = decStock.executeUpdate();
                            if (updated == 0) throw new SQLException("Stock update failed for product id=" + pid);
                        }
                    }
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE users SET balance = balance - ? WHERE id=?")) {
                    ps.setBigDecimal(1, discounted);
                    ps.setInt(2, userId);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE orders SET status='PAID' WHERE id=?")) {
                    ps.setInt(1, orderId);
                    ps.executeUpdate();
                }

                con.commit();
            } catch (Exception e) {
                con.rollback();
                throw e instanceof SQLException ? (SQLException) e : new SQLException(e);
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    static void addCategory(String name) throws SQLException {
        Validation.notBlank(name, "Category name required");
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement("INSERT INTO categories(name) VALUES (?)")) {
            ps.setString(1, name.trim());
            ps.executeUpdate();
        }
    }

    static void addProduct(String name, BigDecimal price, int stock, int categoryId) throws SQLException {
        Validation.notBlank(name, "Product name required");
        Validation.price(price, "Price must be > 0");
        Validation.positiveInt(stock, "Stock must be > 0");

        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO products(name, price, stock, category_id) VALUES (?,?,?,?)")) {
            ps.setString(1, name.trim());
            ps.setBigDecimal(2, price);
            ps.setInt(3, stock);
            ps.setInt(4, categoryId);
            ps.executeUpdate();
        }
    }
}
