package kz.shop.factory;

import kz.shop.repo.OrderRepo;

public final class RepoFactory {
    private RepoFactory() {}

    public static OrderRepo orders() { return new OrderRepo(); }
}
