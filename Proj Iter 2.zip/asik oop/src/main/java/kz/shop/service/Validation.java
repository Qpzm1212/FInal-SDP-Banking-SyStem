package kz.shop.service;

import java.math.BigDecimal;

public final class Validation {
    private Validation() {}

    public static void positiveInt(int v, String msg) {
        if (v <= 0) throw new IllegalArgumentException(msg);
    }

    public static void notBlank(String s, String msg) {
        if (s == null || s.trim().isEmpty()) throw new IllegalArgumentException(msg);
    }

    public static void price(BigDecimal p, String msg) {
        if (p == null || p.signum() <= 0) throw new IllegalArgumentException(msg);
    }
}
