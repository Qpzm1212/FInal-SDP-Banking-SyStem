package kz.shop.repo;

import kz.shop.Db;

import java.sql.*;

public class OrderRepo {

    // Печатаем "полное описание заказа" одной таблицей через JOIN
    public void printFullOrderDescription(int orderId) throws SQLException {
        String sql =
                "SELECT " +
                        " o.id AS order_id, " +
                        " u.name AS user_name, " +
                        " p.name AS product_name, " +
                        " oi.qty, oi.unit_price " +
                        "FROM orders o " +
                        "JOIN users u ON u.id = o.user_id " +
                        "JOIN order_items oi ON oi.order_id = o.id " +
                        "JOIN products p ON p.id = oi.product_id " +
                        "WHERE o.id = ? ";


        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            try (ResultSet rs = ps.executeQuery()) {
                boolean any = false;
                while (rs.next()) {
                    if (!any) {
                        any = true;
                        System.out.println("ORDER #" + rs.getInt("order_id")
                                + " | status=" + rs.getString("status")
                                + " | created_at=" + rs.getTimestamp("created_at"));
                        System.out.println("BUYER: " + rs.getString("user_name")
                                + " (id=" + rs.getInt("user_id")
                                + ", role=" + rs.getString("user_role") + ")");
                        System.out.println("--------------------------------------------------");
                        System.out.println("product | category | qty | unit_price | line_total");
                    }
                    System.out.println(
                            rs.getString("product_name") + " | " +
                                    rs.getString("category_name") + " | " +
                                    rs.getInt("qty") + " | " +
                                    rs.getBigDecimal("unit_price") + " | " +
                                    rs.getBigDecimal("line_total")
                    );
                }
                if (any) {
                    System.out.println("--------------------------------------------------");
                    // total уже хранится в orders.total
                } else {
                    System.out.println("Order not found or empty items.");
                }
            }
        }
    }
}
