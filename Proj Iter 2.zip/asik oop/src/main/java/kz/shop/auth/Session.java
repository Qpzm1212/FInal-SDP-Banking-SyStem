package kz.shop.auth;

public final class Session {
    private static Integer userId;
    private static Role role;

    private Session() {}

    public static void login(int uid, Role r) { userId = uid; role = r; }
    public static void logout() { userId = null; role = null; }

    public static boolean isAuth() { return userId != null; }
    public static int userId() { return userId; }
    public static Role role() { return role; }
}
