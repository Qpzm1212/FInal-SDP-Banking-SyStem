package kz.shop.auth;

public enum Role {
    USER, MANAGER, ADMIN
}
