package kz.shop.auth;

public final class Security {
    private Security() {}

    public static void require(Role... allowed) {
        if (!Session.isAuth()) throw new RuntimeException("401 Unauthorized (login first)");
        Role r = Session.role();
        for (Role a : allowed) if (a == r) return;
        throw new RuntimeException("403 Forbidden (no access)");
    }
}